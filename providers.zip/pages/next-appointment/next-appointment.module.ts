import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NextAppointmentPage } from './next-appointment';

@NgModule({
  declarations: [
  //  NextAppointmentPage,
  ],
  imports: [
    IonicPageModule.forChild(NextAppointmentPage),
  ],
})
export class NextAppointmentPageModule {}
