import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PastAppointmentPage } from './past-appointment';

@NgModule({
  declarations: [
  //  PastAppointmentPage,
  ],
  imports: [
    IonicPageModule.forChild(PastAppointmentPage),
  ],
})
export class PastAppointmentPageModule {}
