import {Injectable} from '@angular/core';


@Injectable()
export class ConstantProvider {

    requestUrl = 'http://localhost/doctor_appointment/administrator/restapi/';


}
